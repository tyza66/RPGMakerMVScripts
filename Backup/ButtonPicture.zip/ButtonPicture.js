//=============================================================================
// RPG Maker MZ - Button Picture
//=============================================================================

/*:
 * @target MZ
 * @plugindesc 使图片可点击.
 * @author Yoji Ojima
 *
 * @help ButtonPicture.js
 *
 * 该插件提供了一个命令，可以在图片被点击时调用一个公共事件
 * 点击。
 *
 * 在以下步骤中使用它。
 * 1. 执行“显示图片”以显示您的按钮图像。
 * 2.调用插件命令“设置按钮图片”。
 *
 * @command set
 * @text 设置按钮图片
 * @desc 使指定的图片可点击。
 *
 * @arg 图片ID编号
 * @type number
 * @min 1
 * @max 100
 * @default 1
 * @text 图像编号
 * @desc 图片的控制编号。
 *
 * @arg 公共事件ID
 * @type 公共事件
 * @default 1
 * @text 公共事件
 * @desc 点击图片时调用的常见事件。
 */

/*:ja
 * @target MZ
 * @plugindesc ピクチャをクリック可能にします。
 * @author Yoji Ojima
 *
 * @help ButtonPicture.js
 *
 * このプラグインは、ピクチャのクリック時にコモンイベントを呼び出すコマンドを
 * 提供します。
 *
 * 次の手順で使用してください。
 *   1. 「ピクチャの表示」を実行して、ボタン画像を表示します。
 *   2. プラグインコマンド「ボタンピクチャの設定」を呼び出します。
 *
 * @command set
 * @text ボタンピクチャの設定
 * @desc 指定したピクチャをクリック可能にします。
 *
 * @arg 图片ID编号
 * @type number
 * @min 1
 * @max 100
 * @default 1
 * @text ピクチャ番号
 * @desc ピクチャの管理番号です。
 *
 * @arg 公共事件ID
 * @type 公共事件
 * @default 1
 * @text コモンイベント
 * @desc ピクチャがクリックされた時に呼び出すコモンイベントです。
 */

(() => {
    const pluginName = "ButtonPicture";

    PluginManager.registerCommand(pluginName, "set", args => {
        const 图片ID编号 = Number(args.图片ID编号);
        const 公共事件ID = Number(args.公共事件ID);
        const picture = $gameScreen.picture(图片ID编号);
        if (picture) {
            picture.mzkp_公共事件ID = 公共事件ID;
        }
    });

    Sprite_Picture.prototype.isClickEnabled = function() {
        const picture = this.picture();
        return picture && picture.mzkp_公共事件ID && !$gameMessage.isBusy();
    };

    Sprite_Picture.prototype.onClick = function() {
        $gameTemp.reserveCommonEvent(this.picture().mzkp_公共事件ID);
    };

    Spriteset_Base.prototype.mzkp_isAnyPicturePressed = function() {
        return this._pictureContainer.children.some(sprite =>
            sprite.isPressed()
        );
    };

    const _Scene_Map_isAnyButtonPressed =
        Scene_Map.prototype.isAnyButtonPressed;
    Scene_Map.prototype.isAnyButtonPressed = function() {
        return (
            _Scene_Map_isAnyButtonPressed.apply(this, arguments) ||
            this._spriteset.mzkp_isAnyPicturePressed()
        );
    };
})();
